package com.example.listview.retrofit

object APIClient {
    private var instance : Retrofit?=null
}