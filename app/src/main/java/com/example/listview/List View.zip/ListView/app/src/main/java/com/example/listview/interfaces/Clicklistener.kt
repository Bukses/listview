package com.example.listview.interfaces

interface Clicklistener {
    fun setOnClickListener (url: String)
}
