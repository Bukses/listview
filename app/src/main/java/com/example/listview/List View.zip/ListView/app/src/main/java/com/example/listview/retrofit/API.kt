package com.example.listview.retrofit

interface API {

}