package com.example.listview

data class User(val text: String, val image: Int, val url: String)